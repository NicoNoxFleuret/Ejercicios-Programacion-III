import java.util.Stack;

public class Pila {
    //objeto de la clase stack
    private Stack<String> coleccion;
    //=new Stack();
    public Pila(){
        //no tienen retrono y se llama igual a la clase
        coleccion=new Stack<String>(); //menor mayyor es en donde debe ir el tipode element
    }
    public void push(String dato){
        coleccion.push(dato); //agrega un elemento

    }
    public String pop() throws Exception{

        if (coleccion.empty())
            throw new Exception("Error en métofo pop, pila vacia");
        return coleccion.pop();//el pop es para eliminar un elemento

    }
    public String cima() throws Exception{


        return coleccion.peek();
    }

    public boolean empty() {
        return coleccion.isEmpty();
    }
    public boolean registro(String valor) {
        return coleccion.contains(valor);
    }

    @Override
    public String toString() {
        StringBuilder listado=new StringBuilder();//es una clase que permite ir anexando cualquier tipode dato y formar un slso string
       for (int i=coleccion.size()-1; i>=0; i--){
           //i>=0; se trata de un elemento  y queremos llegar a 0
           listado.append(coleccion.get(i)+"\n");// le s //append se va agrandando a lo que le agrewge
       }
       return listado.toString(); //para que se trasnforme en el mismo tipo de dato
    }

    public int size() {
        return coleccion.size();
    }

    //hacer el proceso de busqueda, desde la cima hasta el elemento buscado
}
