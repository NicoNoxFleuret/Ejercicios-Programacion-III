import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventamna {
    private JPanel principal;
    private JTextField txtTexto;
    private JButton btnPush;
    private JButton btnPop;
    private JTextArea txtMostrar;
    private JLabel lblTexto;
    private JButton btnCima;
    private JButton btnBuscar;
    private Pila data = new Pila();

    public Ventamna() {
        btnPush.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if (data.size() < 10) {
                        data.push(txtTexto.getText());
                        txtMostrar.setText(data.toString()); // Se enlistan todos los elementos

                    } else {
                       throw new Exception("Solo se pueden almacenar 10 elementos");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }

        });

        btnPop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String eliminado = data.pop();
                    JOptionPane.showMessageDialog(null, "Se eliminó " + eliminado);
                    txtMostrar.setText(data.toString());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });

        btnCima.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if (data.empty()) {
                        JOptionPane.showMessageDialog(null, "La pila está vacía.");
                    } else {
                        String ultimo = data.cima();
                        JOptionPane.showMessageDialog(null, "El último elemento de la cima es: " + ultimo);
                        txtMostrar.setText(data.toString());
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String objBuscado = txtTexto.getText();
               /* if ( objBuscado.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, ingrese un valor para buscar.");
                }*/
                if (data.empty()) {
                    JOptionPane.showMessageDialog(null, "La pila esta Vacia.");

                }
                if (data.registro(objBuscado)) {
                    JOptionPane.showMessageDialog(null, "El  " + objBuscado + " se encuentra registrada");
                } else {
                    JOptionPane.showMessageDialog(null, "El  " + objBuscado + " no está resgistrada");
                }
            }
        });

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventamna().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
