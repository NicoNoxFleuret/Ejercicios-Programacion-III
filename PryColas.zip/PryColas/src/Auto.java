public class Auto {
    private String marca;
    private int anio;
    private int valorPagar;

    public Auto(String marca, int anio, int valorPagar) {
        this.marca = marca;
        this.anio = anio;
        this.valorPagar = valorPagar;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getValorPagar() {
        return valorPagar;
    }

    public void setValorPagar(int valorPagar) {
        this.valorPagar = valorPagar;
    }

    @Override
    public String toString() {
        return "\n-----Auto-----\n"+

                "Marca: "+marca+
                "\t Año: "+anio+
                "\t Valor a pagar: $" + valorPagar;
    }
}
