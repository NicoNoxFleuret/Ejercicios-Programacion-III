import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel principal;
    private JComboBox cboMarca;
    private JTextField txtAnio;
    private JButton btnEncolar;
    private JButton btnDesencolar;
    private JTextArea txtListado;
    private JLabel lblPago;
    private ColasAutos autos=new ColasAutos();
    private int valorPagar;


    public Ventana() {


        cboMarca.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String marca = cboMarca.getSelectedItem().toString();
                    int anio = Integer.parseInt(txtAnio.getText());

                    if (anio > 2025) {
                        JOptionPane.showMessageDialog(null, "El año no puede ser mayor a 2025");

                    } else if (anio == 2025) {
                        valorPagar = 0;
                    } else {
                        int restante = 2025 - anio;
                        valorPagar = restante * 50;
                    }

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Por favor ingrese un año válido.");
                }
            }
        });
        btnEncolar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String marca=cboMarca.getSelectedItem().toString();

                int anio=Integer.parseInt(txtAnio.getText());
                    autos.encolar(new Auto(marca, anio,valorPagar));
                    txtListado.setText(autos.listarTodos());
            }
        });

        btnDesencolar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Auto atendido=autos.desencolar();
                    lblPago.setText("Ultimo Auto Atendido: \n"+atendido.toString());
                    txtListado.setText(autos.listarTodos());

                } catch (Exception ex){

                JOptionPane.showMessageDialog(null, ex.getMessage());
              }
            }
        });

   }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
